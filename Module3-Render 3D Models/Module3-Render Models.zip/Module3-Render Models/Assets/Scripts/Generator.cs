using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generator : MonoBehaviour
{
    public GameObject boxToGenerate;
    
    void SetObj(int pointx, int pointy){
        transform.position = transform.position + new Vector3(pointx * 1 * Time.deltaTime, pointy * 1 * Time.deltaTime, 0);
    }

    void GenerateObj() 
    {
        // instantiate the box object
        Instantiate(boxToGenerate);  
    }

    void GenerateObj(int pointx, int pointy) 
    {
        SetObj(pointx, pointy);
        // instantiate the box object
        Instantiate(boxToGenerate);  
    }

}